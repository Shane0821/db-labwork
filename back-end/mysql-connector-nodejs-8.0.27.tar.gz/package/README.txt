Copyright (c) 2015, 2021, Oracle and/or its affiliates.

This is a release of MySQL Connector/Node.js, Oracle's Node.js driver for MySQL.

License information can be found in the LICENSE file.

This distribution may include materials developed by third parties.
For license and attribution notices for these materials, please refer to the LICENSE file.

For more information on MySQL Connector/Node.js, visit
http://dev.mysql.com/doc/dev/connector-nodejs/8.0/

For additional downloads and the source of MySQL Connector/Node.js, visit
http://dev.mysql.com/downloads

MySQL Connector/Node.js is brought to you by the MySQL team at Oracle.
